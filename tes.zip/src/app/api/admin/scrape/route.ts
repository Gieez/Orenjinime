// src/app/api/admin/scrape/route.ts
import { NextResponse } from "next/server";
import { ScraperSyncService } from "@/scraper/persist/sync";

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const pages = body.pages || "50";

    const syncService = new ScraperSyncService();
    const result = await syncService.syncCatalog(pages);

    return NextResponse.json({
      success: true,
      message: "Scraping completed successfully",
      processedCount: result.processedCount,
    });
  } catch (error: any) {
    return NextResponse.json(
      { 
        success: false, 
        error: error.message || "Internal Server Error" 
      },
      { status: 500 }
    );
  }
}